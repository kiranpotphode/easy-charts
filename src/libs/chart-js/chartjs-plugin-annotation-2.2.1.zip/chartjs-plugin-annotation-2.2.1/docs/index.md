---
home: true
heroImage: /hero.svg
actionText: Get Started →
actionLink: /guide/
footer: MIT Licensed | Copyright © 2016-2021 chartjs-plugin-annotation contributors
---

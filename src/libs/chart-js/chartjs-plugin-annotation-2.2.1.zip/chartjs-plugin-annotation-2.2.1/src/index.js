import {Chart} from 'chart.js';
import Annotation from './annotation';

Chart.register(Annotation);

export default Annotation;
